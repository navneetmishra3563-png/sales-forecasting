"""
Lightweight sanity tests (no pytest required to read, but pytest to run).

Run with:
    pytest tests/
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data_loader import load_sales_data, train_test_split_by_date
from src.evaluate import evaluate_forecast, mean_absolute_percentage_error

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "sample_sales_data.csv"


def test_load_sales_data_shape():
    df = load_sales_data(str(DATA_PATH))
    assert "sales" in df.columns
    assert df.index.is_monotonic_increasing
    assert not df["sales"].isna().any()


def test_train_test_split_is_chronological():
    df = load_sales_data(str(DATA_PATH))
    train, test = train_test_split_by_date(df, test_size_days=30)
    assert len(test) == 30
    assert train.index.max() < test.index.min()


def test_mape_matches_hand_calc():
    y_true = np.array([100.0, 200.0, 300.0])
    y_pred = np.array([110.0, 190.0, 300.0])
    expected = np.mean([10 / 100, 10 / 200, 0 / 300]) * 100
    assert abs(mean_absolute_percentage_error(y_true, y_pred) - expected) < 1e-6


def test_evaluate_forecast_returns_expected_keys():
    idx = pd.date_range("2024-01-01", periods=5, freq="D")
    y_true = pd.Series([10, 20, 30, 40, 50], index=idx)
    y_pred = pd.Series([12, 18, 33, 37, 51], index=idx)
    metrics = evaluate_forecast(y_true, y_pred, model_name="test")
    assert set(metrics.keys()) == {"model", "MAE", "RMSE", "MAPE_%"}
    assert metrics["model"] == "test"
