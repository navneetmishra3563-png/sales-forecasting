"""
preprocessing.py

Exploratory / preparation helpers for the ARIMA pipeline:
- Augmented Dickey-Fuller stationarity test
- Differencing helper
- Seasonal decomposition (trend / seasonal / residual)

Prophet needs none of this (it takes the raw series directly), but ARIMA
requires a stationary series, so these are used specifically by
arima_model.py.
"""

import pandas as pd


def check_stationarity(series: pd.Series, name: str = "series", verbose: bool = True) -> bool:
    """Run an Augmented Dickey-Fuller test. Returns True if stationary (p < 0.05)."""
    from statsmodels.tsa.stattools import adfuller

    result = adfuller(series.dropna())
    adf_stat, p_value = result[0], result[1]
    is_stationary = p_value < 0.05

    if verbose:
        print(f"ADF test on '{name}': statistic={adf_stat:.4f}, p-value={p_value:.4f}")
        print(f"  -> {'Stationary' if is_stationary else 'NOT stationary'} (alpha=0.05)")

    return is_stationary


def difference_series(series: pd.Series, periods: int = 1) -> pd.Series:
    """Simple differencing, used to make a series stationary before ARIMA fitting."""
    return series.diff(periods=periods).dropna()


def decompose(series: pd.Series, period: int = 7, model: str = "additive"):
    """Seasonal-trend decomposition. `period=7` captures weekly seasonality in daily data."""
    from statsmodels.tsa.seasonal import seasonal_decompose

    result = seasonal_decompose(series, model=model, period=period, extrapolate_trend="freq")
    return result


def find_min_differencing_order(series: pd.Series, max_d: int = 2) -> int:
    """Find the smallest differencing order `d` that yields a stationary series (used for ARIMA(p,d,q))."""
    from statsmodels.tsa.stattools import adfuller

    current = series.copy()
    for d in range(max_d + 1):
        p_value = adfuller(current.dropna())[1]
        if p_value < 0.05:
            return d
        current = current.diff().dropna()
    return max_d


if __name__ == "__main__":
    from data_loader import load_sales_data

    df = load_sales_data("data/sample_sales_data.csv")
    check_stationarity(df["sales"], name="raw sales")
    d = find_min_differencing_order(df["sales"])
    print(f"Suggested differencing order d = {d}")
