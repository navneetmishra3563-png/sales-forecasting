"""
visualize.py

Plotting helpers: history + forecast with confidence interval, and a
side-by-side ARIMA vs Prophet comparison chart. Saves PNGs to outputs/
(headless-safe: uses the 'Agg' backend so it works without a display).
"""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def plot_forecast(
    train: pd.Series,
    test: pd.Series,
    forecast_df: pd.DataFrame,
    title: str = "Sales Forecast",
    save_path: str = "outputs/forecast.png",
    history_days: int = 180,
):
    """Plot recent history, actual holdout values, and the forecast with its confidence band."""
    fig, ax = plt.subplots(figsize=(12, 6))

    recent_train = train.iloc[-history_days:]
    ax.plot(recent_train.index, recent_train.values, label="Train (recent history)", color="#4C72B0")
    ax.plot(test.index, test.values, label="Actual (holdout)", color="#333333", linewidth=2)
    ax.plot(forecast_df.index, forecast_df["forecast"], label="Forecast", color="#DD8452", linewidth=2)

    if "lower_ci" in forecast_df.columns and "upper_ci" in forecast_df.columns:
        ax.fill_between(
            forecast_df.index,
            forecast_df["lower_ci"],
            forecast_df["upper_ci"],
            color="#DD8452",
            alpha=0.2,
            label="95% confidence interval",
        )

    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel("Sales")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"Saved plot -> {save_path}")


def plot_model_comparison(
    test: pd.Series,
    forecasts: dict,
    title: str = "ARIMA vs Prophet",
    save_path: str = "outputs/model_comparison.png",
):
    """forecasts: dict like {'ARIMA': forecast_df_arima, 'Prophet': forecast_df_prophet}"""
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(test.index, test.values, label="Actual", color="#333333", linewidth=2.5)

    colors = ["#DD8452", "#55A868", "#C44E52", "#8172B2"]
    for (name, fdf), color in zip(forecasts.items(), colors):
        ax.plot(fdf.index, fdf["forecast"], label=name, linewidth=2, color=color)

    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel("Sales")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"Saved plot -> {save_path}")
