"""
prophet_model.py

Wrapper around Meta's Prophet. Prophet expects a DataFrame with columns
'ds' (date) and 'y' (value), so this handles the conversion from our
standard {index=date, column='sales'} format automatically.
"""

from typing import Optional

import pandas as pd


class ProphetForecaster:
    def __init__(
        self,
        yearly_seasonality: bool = True,
        weekly_seasonality: bool = True,
        daily_seasonality: bool = False,
        seasonality_mode: str = "additive",
        changepoint_prior_scale: float = 0.05,
        country_holidays: Optional[str] = "US",
    ):
        """
        seasonality_mode: 'additive' (default) or 'multiplicative'. Use 'multiplicative'
            if seasonal swings grow proportionally with the sales level.
        changepoint_prior_scale: flexibility of the trend. Higher = more flexible/overfit-prone.
        country_holidays: ISO country code (e.g. 'US', 'GB') to auto-add holiday effects, or None.
        """
        from prophet import Prophet

        self.model = Prophet(
            yearly_seasonality=yearly_seasonality,
            weekly_seasonality=weekly_seasonality,
            daily_seasonality=daily_seasonality,
            seasonality_mode=seasonality_mode,
            changepoint_prior_scale=changepoint_prior_scale,
        )
        if country_holidays:
            self.model.add_country_holidays(country_name=country_holidays)

    @staticmethod
    def _to_prophet_format(series: pd.Series) -> pd.DataFrame:
        df = series.reset_index()
        df.columns = ["ds", "y"]
        return df

    def fit(self, train: pd.Series):
        prophet_df = self._to_prophet_format(train)
        self.model.fit(prophet_df)
        return self.model

    def forecast(self, steps: int, freq: str = "D") -> pd.DataFrame:
        """Return a DataFrame indexed by date with forecast mean and 95% interval,
        for the `steps` periods immediately following the training data."""
        future = self.model.make_future_dataframe(periods=steps, freq=freq)
        full_forecast = self.model.predict(future)

        result = full_forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail(steps).copy()
        result = result.rename(
            columns={"ds": "date", "yhat": "forecast", "yhat_lower": "lower_ci", "yhat_upper": "upper_ci"}
        )
        result = result.set_index("date")
        return result

    def plot_components(self):
        """Requires the fitted model; returns a matplotlib figure showing trend/weekly/yearly components."""
        future = self.model.make_future_dataframe(periods=0)
        forecast = self.model.predict(future)
        return self.model.plot_components(forecast)


if __name__ == "__main__":
    from data_loader import load_sales_data, train_test_split_by_date
    from evaluate import evaluate_forecast

    df = load_sales_data("data/sample_sales_data.csv")
    train, test = train_test_split_by_date(df, test_size_days=30)

    forecaster = ProphetForecaster()
    forecaster.fit(train["sales"])

    result = forecaster.forecast(steps=len(test))
    metrics = evaluate_forecast(test["sales"], result["forecast"], model_name="Prophet")
    print(metrics)
