"""
data_loader.py

Loads a sales CSV (date, sales columns), validates it, fills any missing
calendar days, and splits it into train/test sets for backtesting.
"""

from typing import Tuple

import pandas as pd


def load_sales_data(csv_path: str, date_col: str = "date", value_col: str = "sales") -> pd.DataFrame:
    """Load a CSV and return a DataFrame indexed by a continuous daily DatetimeIndex."""
    df = pd.read_csv(csv_path, parse_dates=[date_col])

    if value_col not in df.columns:
        raise ValueError(f"Expected a '{value_col}' column in {csv_path}, found: {list(df.columns)}")

    df = df[[date_col, value_col]].rename(columns={date_col: "date", value_col: "sales"})
    df = df.sort_values("date").drop_duplicates(subset="date")
    df = df.set_index("date")

    # Reindex to a continuous daily range and interpolate any gaps
    full_range = pd.date_range(df.index.min(), df.index.max(), freq="D")
    df = df.reindex(full_range)
    df.index.name = "date"
    if df["sales"].isna().any():
        n_missing = int(df["sales"].isna().sum())
        df["sales"] = df["sales"].interpolate(method="linear").ffill().bfill()
        print(f"[data_loader] Filled {n_missing} missing day(s) via linear interpolation.")

    return df


def train_test_split_by_date(
    df: pd.DataFrame, test_size_days: int = 90
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Chronological split: last `test_size_days` rows become the test/holdout set.

    Time series must never be split randomly -- the test set has to be the
    most recent period so the evaluation reflects real forecasting conditions.
    """
    if test_size_days >= len(df):
        raise ValueError("test_size_days must be smaller than the full dataset length.")

    train = df.iloc[: -test_size_days].copy()
    test = df.iloc[-test_size_days:].copy()
    return train, test


if __name__ == "__main__":
    data = load_sales_data("data/sample_sales_data.csv")
    train, test = train_test_split_by_date(data, test_size_days=90)
    print(f"Full data:  {data.shape[0]} rows ({data.index.min().date()} -> {data.index.max().date()})")
    print(f"Train:      {train.shape[0]} rows ({train.index.min().date()} -> {train.index.max().date()})")
    print(f"Test:       {test.shape[0]} rows ({test.index.min().date()} -> {test.index.max().date()})")
