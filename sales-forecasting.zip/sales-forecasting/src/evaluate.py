"""
evaluate.py

Shared forecast accuracy metrics used to compare ARIMA vs Prophet
(and any future model) on the same holdout set.
"""

from typing import Dict

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error


def mean_absolute_percentage_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    mask = y_true != 0
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)


def evaluate_forecast(y_true: pd.Series, y_pred: pd.Series, model_name: str = "model") -> Dict[str, float]:
    """Compute MAE, RMSE, MAPE for a forecast against actuals. Both series must be aligned by index."""
    y_true_aligned, y_pred_aligned = y_true.align(y_pred, join="inner")

    if len(y_true_aligned) == 0:
        raise ValueError("No overlapping dates between y_true and y_pred -- check index alignment.")

    mae = mean_absolute_error(y_true_aligned, y_pred_aligned)
    rmse = float(np.sqrt(mean_squared_error(y_true_aligned, y_pred_aligned)))
    mape = mean_absolute_percentage_error(y_true_aligned.values, y_pred_aligned.values)

    metrics = {"model": model_name, "MAE": round(mae, 2), "RMSE": round(rmse, 2), "MAPE_%": round(mape, 2)}
    return metrics


def compare_models(*metric_dicts: Dict[str, float]) -> pd.DataFrame:
    """Combine several evaluate_forecast() outputs into one comparison table, sorted by RMSE."""
    df = pd.DataFrame(list(metric_dicts)).set_index("model")
    return df.sort_values("RMSE")


if __name__ == "__main__":
    # Quick self-test with synthetic numbers
    idx = pd.date_range("2024-01-01", periods=10, freq="D")
    truth = pd.Series(np.linspace(100, 110, 10), index=idx)
    pred_a = truth + np.random.default_rng(0).normal(0, 2, 10)
    pred_b = truth + np.random.default_rng(1).normal(0, 5, 10)

    m_a = evaluate_forecast(truth, pred_a, "model_a")
    m_b = evaluate_forecast(truth, pred_b, "model_b")
    print(compare_models(m_a, m_b))
