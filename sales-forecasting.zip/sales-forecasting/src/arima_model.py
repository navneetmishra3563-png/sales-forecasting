"""
arima_model.py

SARIMA (Seasonal ARIMA) wrapper around statsmodels. Includes a small grid
search over (p,d,q) and seasonal (P,D,Q,m) orders using AIC, since hand-
picking ARIMA orders is the most common stumbling block for beginners.

For daily retail-style data with weekly seasonality, m=7 is the right
seasonal period.
"""

import itertools
import warnings
from typing import Optional, Tuple

import pandas as pd


class ARIMAForecaster:
    def __init__(self, seasonal_period: int = 7):
        self.seasonal_period = seasonal_period
        self.model = None
        self.results = None
        self.order: Optional[Tuple[int, int, int]] = None
        self.seasonal_order: Optional[Tuple[int, int, int, int]] = None

    def auto_select_order(
        self,
        train: pd.Series,
        p_range=range(0, 3),
        d_range=range(0, 2),
        q_range=range(0, 3),
        seasonal_P=(0, 1),
        seasonal_D=(0, 1),
        seasonal_Q=(0, 1),
        verbose: bool = True,
    ) -> Tuple[Tuple[int, int, int], Tuple[int, int, int, int]]:
        """Small grid search over SARIMA orders, selecting the combination with the lowest AIC.

        This is intentionally a lightweight alternative to pmdarima's auto_arima
        (which has flaky installs on some platforms) using only statsmodels.
        For large search spaces, consider installing pmdarima instead.
        """
        from statsmodels.tsa.statespace.sarimax import SARIMAX

        best_aic = float("inf")
        best_order = None
        best_seasonal_order = None

        combos = list(itertools.product(p_range, d_range, q_range, seasonal_P, seasonal_D, seasonal_Q))
        if verbose:
            print(f"Searching {len(combos)} SARIMA order combinations...")

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            for p, d, q, P, D, Q in combos:
                order = (p, d, q)
                seasonal_order = (P, D, Q, self.seasonal_period)
                try:
                    model = SARIMAX(
                        train,
                        order=order,
                        seasonal_order=seasonal_order,
                        enforce_stationarity=False,
                        enforce_invertibility=False,
                    )
                    fit = model.fit(disp=False)
                    if fit.aic < best_aic:
                        best_aic = fit.aic
                        best_order = order
                        best_seasonal_order = seasonal_order
                except Exception:
                    continue

        if best_order is None:
            raise RuntimeError("SARIMA order search failed to converge on any combination.")

        if verbose:
            print(f"Best order: {best_order}, seasonal_order: {best_seasonal_order}, AIC={best_aic:.2f}")

        self.order, self.seasonal_order = best_order, best_seasonal_order
        return best_order, best_seasonal_order

    def fit(
        self,
        train: pd.Series,
        order: Optional[Tuple[int, int, int]] = None,
        seasonal_order: Optional[Tuple[int, int, int, int]] = None,
    ):
        """Fit SARIMA. If order/seasonal_order aren't given, uses whatever auto_select_order found,
        or falls back to a sensible default (1,1,1)x(1,1,1,7)."""
        from statsmodels.tsa.statespace.sarimax import SARIMAX

        order = order or self.order or (1, 1, 1)
        seasonal_order = seasonal_order or self.seasonal_order or (1, 1, 1, self.seasonal_period)

        self.model = SARIMAX(
            train,
            order=order,
            seasonal_order=seasonal_order,
            enforce_stationarity=False,
            enforce_invertibility=False,
        )
        self.results = self.model.fit(disp=False)
        self.order, self.seasonal_order = order, seasonal_order
        return self.results

    def forecast(self, steps: int) -> pd.DataFrame:
        """Return a DataFrame with forecast mean and 95% confidence interval."""
        if self.results is None:
            raise RuntimeError("Call .fit() before .forecast().")

        pred = self.results.get_forecast(steps=steps)
        forecast_df = pd.DataFrame(
            {
                "forecast": pred.predicted_mean,
                "lower_ci": pred.conf_int(alpha=0.05).iloc[:, 0],
                "upper_ci": pred.conf_int(alpha=0.05).iloc[:, 1],
            }
        )
        return forecast_df

    def summary(self) -> str:
        if self.results is None:
            raise RuntimeError("Call .fit() before .summary().")
        return str(self.results.summary())


if __name__ == "__main__":
    from data_loader import load_sales_data, train_test_split_by_date
    from evaluate import evaluate_forecast

    df = load_sales_data("data/sample_sales_data.csv")
    train, test = train_test_split_by_date(df, test_size_days=30)

    forecaster = ARIMAForecaster(seasonal_period=7)
    # Small search space so this runs quickly as a smoke test; widen ranges for real use.
    forecaster.auto_select_order(train["sales"], p_range=range(0, 2), d_range=range(0, 2), q_range=range(0, 2))
    forecaster.fit(train["sales"])

    result = forecaster.forecast(steps=len(test))
    metrics = evaluate_forecast(test["sales"], result["forecast"], model_name="ARIMA")
    print(metrics)
