# Sales Forecasting with ARIMA & Prophet

End-to-end sales forecasting project in Python, comparing two classic
time-series approaches — **SARIMA** (statsmodels) and **Prophet** (Meta) —
on the same dataset, with backtesting, evaluation metrics, and plots.

```
Train history ─────────────► ARIMA  ──┐
                                        ├──► forecast + metrics + plots
Train history ─────────────► Prophet ──┘
```

## Features

- Synthetic daily sales generator (trend + weekly/yearly seasonality + promos + noise) so you can run the whole pipeline with zero setup
- Drop-in support for your own CSV (`date`, `sales` columns)
- Automatic SARIMA order selection via AIC grid search
- Prophet with US holiday effects built in
- Chronological train/test split (no data leakage)
- MAE / RMSE / MAPE evaluation, side-by-side model comparison
- Forecast plots with 95% confidence intervals saved as PNGs
- Lightweight test suite

## Project structure

```
sales-forecasting/
├── data/
│   ├── generate_sample_data.py   # creates a synthetic dataset
│   └── sample_sales_data.csv     # generated output (or bring your own)
├── src/
│   ├── data_loader.py            # CSV loading, gap-filling, train/test split
│   ├── preprocessing.py          # stationarity tests, differencing, decomposition
│   ├── arima_model.py            # SARIMA wrapper + order search
│   ├── prophet_model.py          # Prophet wrapper
│   ├── evaluate.py               # MAE / RMSE / MAPE + comparison table
│   └── visualize.py              # forecast & comparison plots
├── tests/
│   └── test_pipeline.py
├── outputs/                      # generated plots & forecast CSVs land here
├── main.py                       # runs the full pipeline end-to-end
├── requirements.txt
└── README.md
```

## Setup

**1. Clone the repo**

```bash
git clone https://github.com/<your-username>/sales-forecasting.git
cd sales-forecasting
```

**2. Create a virtual environment** (recommended)

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

**3. Install dependencies**

```bash
pip install -r requirements.txt
```

> **Note on Prophet:** Prophet depends on `pystan`/`cmdstanpy` and can be
> the slowest install here. If it gives you trouble:
> - macOS: `brew install cmake` first, then retry
> - Conda users: `conda install -c conda-forge prophet` is usually smoother than pip
> - Or skip it entirely — every script works with `--skip-prophet` and ARIMA alone is fully functional

**4. Generate the sample dataset** (skip this if you're using your own CSV)

```bash
python data/generate_sample_data.py
```

This writes `data/sample_sales_data.csv` — 3 years of daily synthetic sales data.

**5. Run the full pipeline**

```bash
python main.py
```

This will:
1. Load the data and hold out the last 90 days for testing
2. Fit ARIMA and Prophet on the training period
3. Forecast the holdout period with both
4. Print an MAE/RMSE/MAPE comparison table
5. Save plots and forecast CSVs to `outputs/`

## Usage with your own data

Your CSV just needs two columns — any extra columns are ignored:

```csv
date,sales
2023-01-01,412.50
2023-01-02,389.20
...
```

Then run:

```bash
python main.py --data path/to/your_sales.csv --test-days 60
```

## CLI options

| Flag | Default | Description |
|---|---|---|
| `--data` | `data/sample_sales_data.csv` | Path to your CSV (`date`, `sales` columns) |
| `--test-days` | `90` | Size of the holdout window for backtesting |
| `--future-days` | `0` | Extra days to forecast beyond the known data |
| `--seasonal-period` | `7` | ARIMA seasonal period (7 = weekly for daily data) |
| `--skip-arima` | off | Skip the ARIMA model |
| `--skip-prophet` | off | Skip the Prophet model (useful if it's not installed) |
| `--output-dir` | `outputs` | Where plots/CSVs are written |

## Using the models individually

```python
from src.data_loader import load_sales_data, train_test_split_by_date
from src.arima_model import ARIMAForecaster
from src.prophet_model import ProphetForecaster

df = load_sales_data("data/sample_sales_data.csv")
train, test = train_test_split_by_date(df, test_size_days=90)

# ARIMA
arima = ARIMAForecaster(seasonal_period=7)
arima.auto_select_order(train["sales"])   # grid search over (p,d,q)(P,D,Q,7)
arima.fit(train["sales"])
arima_forecast = arima.forecast(steps=90)

# Prophet
prophet = ProphetForecaster(country_holidays="US")
prophet.fit(train["sales"])
prophet_forecast = prophet.forecast(steps=90)
```

## Choosing ARIMA vs Prophet

| | ARIMA / SARIMA | Prophet |
|---|---|---|
| Best for | Stable series with clear autocorrelation structure | Series with strong seasonality, holidays, missing data, outliers |
| Tuning | Needs (p,d,q) orders — this project automates that via AIC search | Mostly automatic; a few intuitive knobs (`changepoint_prior_scale`, `seasonality_mode`) |
| Interpretability | Statistical (coefficients, residual diagnostics) | Decomposable (trend/seasonality/holiday components, plottable) |
| Speed on long series | Slower order search, fast fit | Generally fast |
| Good default when unsure | — | Prophet, then compare against ARIMA |

Run both and let `main.py`'s comparison table decide — that's the point of this repo.

## Running tests

```bash
pip install pytest
pytest tests/
```

## Extending this project

- Swap in real data via a data warehouse / API connector in `src/data_loader.py`
- Add exogenous regressors (e.g. price, promotions) — SARIMAX and Prophet's `add_regressor` both support this
- Add LSTM/XGBoost baselines under `src/` and register them in `main.py`'s comparison
- Wrap `main.py` in a scheduled job (cron / Airflow) for recurring forecasts

## License

MIT — use freely.
