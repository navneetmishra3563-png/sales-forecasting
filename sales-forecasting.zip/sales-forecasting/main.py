"""
main.py

End-to-end pipeline: load data -> train ARIMA + Prophet -> evaluate on a
holdout set -> save comparison plots and a CSV of forecasts.

Usage:
    python main.py
    python main.py --data data/sample_sales_data.csv --test-days 90
    python main.py --skip-prophet          # if Prophet isn't installed yet
    python main.py --future-days 30        # also forecast N days beyond known data
"""

import argparse
import os

from src.data_loader import load_sales_data, train_test_split_by_date
from src.evaluate import compare_models, evaluate_forecast
from src.visualize import plot_forecast, plot_model_comparison


def parse_args():
    parser = argparse.ArgumentParser(description="Sales forecasting with ARIMA and Prophet")
    parser.add_argument("--data", default="data/sample_sales_data.csv", help="Path to CSV with 'date' and 'sales' columns")
    parser.add_argument("--test-days", type=int, default=90, help="Holdout size for backtesting")
    parser.add_argument("--future-days", type=int, default=0, help="Extra days to forecast beyond the known data, after backtesting")
    parser.add_argument("--seasonal-period", type=int, default=7, help="Seasonal period for ARIMA (7 = weekly)")
    parser.add_argument("--skip-arima", action="store_true", help="Skip the ARIMA model")
    parser.add_argument("--skip-prophet", action="store_true", help="Skip the Prophet model")
    parser.add_argument("--output-dir", default="outputs", help="Directory for plots and forecast CSVs")
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    print(f"Loading data from {args.data} ...")
    df = load_sales_data(args.data)
    train, test = train_test_split_by_date(df, test_size_days=args.test_days)
    print(f"Train: {len(train)} days | Test: {len(test)} days\n")

    all_metrics = []
    forecasts_for_plot = {}

    # ---------------- ARIMA ----------------
    if not args.skip_arima:
        print("=" * 60)
        print("Fitting ARIMA (SARIMA) ...")
        from src.arima_model import ARIMAForecaster

        arima = ARIMAForecaster(seasonal_period=args.seasonal_period)
        arima.auto_select_order(train["sales"])
        arima.fit(train["sales"])
        arima_forecast = arima.forecast(steps=len(test))
        arima_forecast.index = test.index  # align to calendar dates

        metrics = evaluate_forecast(test["sales"], arima_forecast["forecast"], model_name="ARIMA")
        print(f"ARIMA metrics: {metrics}")
        all_metrics.append(metrics)
        forecasts_for_plot["ARIMA"] = arima_forecast

        plot_forecast(
            train["sales"], test["sales"], arima_forecast,
            title="ARIMA Forecast vs Actual",
            save_path=os.path.join(args.output_dir, "arima_forecast.png"),
        )
        arima_forecast.to_csv(os.path.join(args.output_dir, "arima_forecast.csv"))

    # ---------------- Prophet ----------------
    if not args.skip_prophet:
        print("=" * 60)
        print("Fitting Prophet ...")
        try:
            from src.prophet_model import ProphetForecaster
        except ImportError:
            print("Prophet isn't installed. Run: pip install prophet   (or use --skip-prophet)")
            ProphetForecaster = None

        if ProphetForecaster is not None:
            prophet = ProphetForecaster()
            prophet.fit(train["sales"])
            prophet_forecast = prophet.forecast(steps=len(test))
            prophet_forecast.index = test.index

            metrics = evaluate_forecast(test["sales"], prophet_forecast["forecast"], model_name="Prophet")
            print(f"Prophet metrics: {metrics}")
            all_metrics.append(metrics)
            forecasts_for_plot["Prophet"] = prophet_forecast

            plot_forecast(
                train["sales"], test["sales"], prophet_forecast,
                title="Prophet Forecast vs Actual",
                save_path=os.path.join(args.output_dir, "prophet_forecast.png"),
            )
            prophet_forecast.to_csv(os.path.join(args.output_dir, "prophet_forecast.csv"))

    # ---------------- Comparison ----------------
    if all_metrics:
        print("=" * 60)
        comparison = compare_models(*all_metrics)
        print("\nModel comparison (sorted by RMSE, lower is better):")
        print(comparison)
        comparison.to_csv(os.path.join(args.output_dir, "model_comparison.csv"))

    if len(forecasts_for_plot) > 1:
        plot_model_comparison(
            test["sales"], forecasts_for_plot,
            save_path=os.path.join(args.output_dir, "model_comparison.png"),
        )

    print(f"\nDone. Plots and CSVs saved in '{args.output_dir}/'.")


if __name__ == "__main__":
    main()
