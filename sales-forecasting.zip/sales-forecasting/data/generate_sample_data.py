"""
generate_sample_data.py

Generates a realistic synthetic daily sales dataset so the project can be
run end-to-end without needing a real dataset. Replace this with your own
CSV (columns: date, sales) at any time -- everything downstream only
depends on that two-column format.

Usage:
    python data/generate_sample_data.py
"""

import numpy as np
import pandas as pd


def generate_sales_data(
    start_date: str = "2021-01-01",
    periods: int = 1095,  # 3 years of daily data
    base_level: float = 500.0,
    trend_per_day: float = 0.35,
    weekly_amplitude: float = 80.0,
    yearly_amplitude: float = 150.0,
    noise_std: float = 35.0,
    seed: int = 42,
) -> pd.DataFrame:
    """Create a synthetic daily sales series with trend + seasonality + noise."""
    rng = np.random.default_rng(seed)

    dates = pd.date_range(start=start_date, periods=periods, freq="D")
    t = np.arange(periods)

    # Long-term upward trend
    trend = base_level + trend_per_day * t

    # Weekly seasonality (higher sales on weekends, e.g. retail pattern)
    day_of_week = dates.dayofweek.values  # Mon=0 ... Sun=6
    weekly_pattern = np.array([0.0, -0.1, -0.05, 0.05, 0.2, 0.9, 0.75])
    weekly = weekly_amplitude * weekly_pattern[day_of_week]

    # Yearly seasonality (holiday bump around Nov-Dec, summer dip)
    day_of_year = dates.dayofyear.values
    yearly = yearly_amplitude * np.sin(2 * np.pi * (day_of_year - 80) / 365.25)
    holiday_bump = 200 * np.exp(-((day_of_year - 330) ** 2) / (2 * 15**2))  # Nov/Dec spike

    # A couple of promotional spikes to make the series more realistic
    promo = np.zeros(periods)
    promo_days = rng.choice(periods, size=6, replace=False)
    for d in promo_days:
        width = 3
        for offset in range(-width, width + 1):
            idx = d + offset
            if 0 <= idx < periods:
                promo[idx] += 150 * np.exp(-(offset**2) / 4)

    noise = rng.normal(0, noise_std, size=periods)

    sales = trend + weekly + yearly + holiday_bump + promo + noise
    sales = np.clip(sales, a_min=10, a_max=None).round(2)

    df = pd.DataFrame({"date": dates, "sales": sales})
    return df


if __name__ == "__main__":
    df = generate_sales_data()
    out_path = "data/sample_sales_data.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df.head())
    print(df.tail())
